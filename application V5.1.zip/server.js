/*
  CREATOR AI V5.1
  Secure AI Backend
  Diamond Playz
  Creator: Virat Mishra

  IMPORTANT:
  Never put your OpenAI API key inside index.html.

  Set it on your server as:

  OPENAI_API_KEY=your_secret_key
*/

const express = require("express");
const cors = require("cors");

const app = express();

const PORT = process.env.PORT || 3000;

const OPENAI_API_KEY =
  process.env.OPENAI_API_KEY;


/* ---------------- SECURITY CHECK ---------------- */

if(!OPENAI_API_KEY){

  console.error(
    "ERROR: OPENAI_API_KEY environment variable is missing."
  );

}


/* ---------------- MIDDLEWARE ---------------- */

app.use(cors({
  origin: "*"
}));

app.use(express.json({
  limit:"100kb"
}));


/* ---------------- HEALTH CHECK ---------------- */

app.get("/",(req,res)=>{

  res.json({
    status:"online",
    app:"Creator AI V5.1",
    creator:"Virat Mishra",
    channel:"Diamond Playz"
  });

});


/* ---------------- AI ENDPOINT ---------------- */

app.post("/api/ai",async(req,res)=>{

  try{

    if(!OPENAI_API_KEY){

      return res.status(500).json({
        error:"AI backend is not configured."
      });

    }


    const {
      tool,
      topic,
      language,
      style,
      extra,
      creator,
      channel,
      handle
    } = req.body;


    if(!topic){

      return res.status(400).json({
        error:"Topic or message is required."
      });

    }


    const systemPrompt = `
You are Creator AI, a professional YouTube
creator assistant.

Creator:
${creator || "Virat Mishra"}

Channel:
${channel || "Diamond Playz"}

Handle:
${handle || "@diamond842"}

Your job is to help create original,
useful and engaging YouTube content.

Rules:

1. Create original content.
2. Do not copy another creator's script.
3. Do not invent facts when factual accuracy matters.
4. Keep the requested language natural.
5. Make hooks interesting without misleading viewers.
6. Give practical creator-focused answers.
7. Follow the requested format.
`;


    const userPrompt = `
Tool:
${tool || "chat"}

Topic / User Request:
${topic}

Language:
${language || "Hinglish"}

Style:
${style || "YouTube creator"}

Additional Instructions:
${extra || "None"}

Create the best possible result for the creator.
`;


    /*
      Responses API request.

      The model can be changed here when you
      choose the model you want your backend to use.
    */

    const response =
      await fetch(
        "https://api.openai.com/v1/responses",
        {
          method:"POST",

          headers:{
            "Content-Type":"application/json",
            "Authorization":
              `Bearer ${OPENAI_API_KEY}`
          },

          body:JSON.stringify({

            model:
              process.env.OPENAI_MODEL ||
              "gpt-5",

            instructions:
              systemPrompt,

            input:
              userPrompt,

            max_output_tokens:1800

          })

        }
      );


    const data =
      await response.json();


    if(!response.ok){

      console.error(
        "OpenAI API error:",
        data
      );

      return res.status(response.status).json({
        error:
          data?.error?.message ||
          "OpenAI request failed."
      });

    }


    /*
      Responses API normally provides
      a convenient output_text value.
    */

    let output =
      data.output_text;


    /*
      Fallback extraction in case
      output_text isn't available.
    */

    if(!output && Array.isArray(data.output)){

      output =
        data.output
          .flatMap(item =>
            Array.isArray(item.content)
              ? item.content
              : []
          )
          .map(content =>
            content.text || ""
          )
          .filter(Boolean)
          .join("\n");

    }


    if(!output){

      output =
        "The AI returned no text.";
    }


    return res.json({
      output
    });


  }catch(error){

    console.error(error);

    return res.status(500).json({
      error:"Internal AI server error."
    });

  }

});


/* ---------------- START SERVER ---------------- */

app.listen(PORT,()=>{

  console.log(
    `Creator AI V5.1 server running on port ${PORT}`
  );

});